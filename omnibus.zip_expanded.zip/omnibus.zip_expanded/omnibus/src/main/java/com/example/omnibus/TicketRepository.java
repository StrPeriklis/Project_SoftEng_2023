package com.example.omnibus;

import org.springframework.data.repository.CrudRepository;

public interface TicketRepository extends CrudRepository<Ticket, Integer> {
	Iterable<Ticket> findAllByUsr(User u);
}
