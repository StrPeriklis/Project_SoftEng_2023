package com.example.omnibus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmnibusApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmnibusApplication.class, args);
	}

}
