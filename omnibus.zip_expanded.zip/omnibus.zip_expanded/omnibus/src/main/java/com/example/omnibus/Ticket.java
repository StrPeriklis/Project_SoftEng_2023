package com.example.omnibus;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Ticket {

	@Id
	  @GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private Integer TicketNum;
	private Date usedDate;
	private Date ekdosi;
	
	@ManyToOne
	  @JoinColumn(name = "lid", referencedColumnName = "id")
	private Line l;
	private String type;
	@ManyToOne
	  @JoinColumn(name = "uid", referencedColumnName = "id")
	private User usr;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getTicketNum() {
		return TicketNum;
	}
	public void setTicketNum(Integer ticketNum) {
		TicketNum = ticketNum;
	}
	public Date getUsedDate() {
		return usedDate;
	}
	public void setUsedDate(Date usedDate) {
		this.usedDate = usedDate;
	}
	public Date getEkdosi() {
		return ekdosi;
	}
	public void setEkdosi(Date ekdosi) {
		this.ekdosi = ekdosi;
	}
	public Line getL() {
		return l;
	}
	public void setL(Line l) {
		this.l = l;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public User getUsr() {
		return usr;
	}
	public void setUsr(User u) {
		usr = u;
	}
	
	
	
}
